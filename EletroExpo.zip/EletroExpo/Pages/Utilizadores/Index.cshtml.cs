using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace EletroExpo.Pages.Utilizadores
{
    public class IndexModel : PageModel
    {
        public List<UtilizadorInfo> listUtilizadores = new List<UtilizadorInfo>();
        public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=.\\SQLEXPRESS;Initial Catalog=EletroExpoDB;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM utilizadores";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read()) 
                            {
                                UtilizadorInfo utilizadorInfo = new UtilizadorInfo();
                                utilizadorInfo.id = "" + reader.GetInt32(0);
                                utilizadorInfo.username = "" + reader.GetString(1);
                                utilizadorInfo.email = reader.GetString(2);
                                utilizadorInfo.password = reader.GetString(3);
                                utilizadorInfo.isVendedor = false;
                                utilizadorInfo.isAtivo = false;
                                utilizadorInfo.isAdministrador = false;

                                listUtilizadores.Add(utilizadorInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }
    }

    public class UtilizadorInfo
    {
        public String id;
        public String username;
        public String email;
        public String password;
        public Boolean isVendedor;
        public Boolean isAtivo;
        public Boolean isAdministrador;
    }
}
